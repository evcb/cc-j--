package pass;

public class UnaryPlus {
	public int promote(char x) {
		return +x;
	}
}
