package junit;

import junit.framework.TestCase;
import junit.framework.Assert;
import pass.Remainder;

public class RemainderTest extends TestCase {
	private Remainder remainder;

	protected void setUp() throws Exception {
		super.setUp();
		remainder = new Remainder();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testRemainder() {
		Assert.assertEquals(0, remainder.remainder(0, 42));
		Assert.assertEquals(0, remainder.remainder(42, 1));
		Assert.assertEquals(1, remainder.remainder(127, 3));
	}
}
